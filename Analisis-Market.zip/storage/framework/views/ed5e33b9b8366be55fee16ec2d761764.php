<?php echo $__env->make('Headers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container py-4">
    <div class="card">
        <div class="card-body">

            <div class="card-header">
                Profile
            </div>
            <?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h6 class="fs-5 col-md-8"><?php echo e($data['title']); ?></h6>
                <p class="fs-6 col-md-4"><?php echo e($data['detailInfo']); ?></p>
                <div class="card-header">
                    Curent
                </div>
                <p class="fs-5 col-md-4"><?php echo e($data['detailPrice']); ?></p>
                <?php $__currentLoopData = $createButton; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                        <li>
                            <form id="cariDataForm" method="GET" action="<?php echo e(route('cari-data')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="search" class="form-control" name="cari-nama" id="cari-nama"
                                    placeholder="Search for Symbols" aria-label="Search" value="<?php echo e($symbol); ?>"
                                    hidden>
                                <a href="#" id="kirimFormulir"
                                    class="nav-link px-2 link-dark"><?php echo e($data['sumray']); ?></a>
                            </form>
                        </li>
                        <li><a href="<?php echo e(route('analisis', ['Symbol' => $symbol])); ?>"
                                class="nav-link px-2 link-dark"><?php echo e($data['analisis']); ?></a></li>
                        <li> <a href="<?php echo e(route('statistik', ['Symbol' => $symbol])); ?>" name="cari-nama" id="cari-nama"
                                class="nav-link px-2 link-dark">
                                <?php echo e($data['statistik']); ?>

                            </a></li>
                        <li> <a href="<?php echo e(route('finansial', ['Symbol' => $symbol])); ?>" name="cari-nama" id="cari-nama"
                                class="nav-link px-2 link-dark">
                                <?php echo e($data['finansial']); ?>

                            </a></li>
                        <li> <a href="<?php echo e(route('profile', ['Symbol' => $symbol])); ?>" name="cari-nama" id="cari-nama"
                                class="nav-link px-2 link-dark">
                                <?php echo e($data['profile']); ?>

                            </a></li>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <br>

            <div class="card">
                <div class="card-header">
                    Finansial
                </div>

                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 mb-md-0">
                    <li>
                        <p class="nav-link px-2 link-dark">Show:</p>
                    </li>
                    <li>
                        <a href="<?php echo e(route('finansial', ['Symbol' => $symbol])); ?>"
                            class="nav-link px-2 link-dark">Income Statement</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('neraca', ['Symbol' => $symbol])); ?>"
                            class="nav-link px-2 link-dark">Balance Sheet</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('arus-kas', ['Symbol' => $symbol])); ?>" name="cari-nama" id="cari-nama"
                            class="nav-link px-2 link-dark">
                            Cash Flow
                        </a>
                    </li>
                </ul>
                <?php $__currentLoopData = $data_income_steatmen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $count['title']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h3 class="fs-5 col-md-8"><?php echo e($title); ?></h3>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="row g-5">
                        <div class="col-md-6">
                            <table class="table table-bordered border-primary">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $count['labels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th class="border"><?php echo e($label); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $count['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td class="border"><?php echo e($value); ?></td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        // Menangani klik pada tautan
        $("#kirimFormulir").on("click", function(e) {
            // Mencegah aksi default dari tautan
            e.preventDefault();

            // Membuka formulir
            $("#cariDataForm").submit();
        });
    });
</script>
<?php echo $__env->make('Footers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\#Project Laravel\Pasar-Saham V.2\Analisis-Market\resources\views/Components/Finansial.blade.php ENDPATH**/ ?>