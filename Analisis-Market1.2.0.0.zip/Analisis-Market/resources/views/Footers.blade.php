</div>

{{-- Footer --}}
<footer class="bg-gray-100 dark:bg-gray-800 p-6 mt-6">
    <div class="container mx-auto">
        <p class="text-sm text-gray-500 dark:text-gray-400">&copy; 2023 Analysis Dashboard. All rights reserved.</p>
    </div>
</footer>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
</script>
</body>

</html>