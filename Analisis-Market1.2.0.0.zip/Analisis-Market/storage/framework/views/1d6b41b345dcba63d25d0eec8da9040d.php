<?php echo $__env->make('Headers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container py-4">
    <div class="card">
        <div class="card-body">
            <?php echo $__env->make('Profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>

            <div class="card">
                <div class="card-header">
                    News
                </div>

                <?php if(isset($response['error'])): ?>
                    <?php $__currentLoopData = $response['error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e($error['img']); ?>" alt="Yahoo Logo" />
                        <h1 class="text-center" style="margin-top:20px;"><?php echo e($error['h1']); ?></h1>
                        <p class="text-center"><?php echo e($error['text1']); ?></p>
                        <p class="text-center"><?php echo e($error['text2']); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <table class="table table-bordered border-primary">
                        <thead>
                            <tr>
                                <th class="border">No</th>
                                <th class="border">Image</th>
                                <th class="border">Title</th>
                                <th class="border">Link</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border"><?php echo e($index + 1); ?></td>
                                    <td class="border"><img src="<?php echo e($data['thumbnail']); ?>" alt="News Image"></td>
                                    <td class="border"><?php echo e($data['title']); ?></td>
                                    <td class="border"><a href="<?php echo e($data['link']); ?>" target="blank">Link</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('Footers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\#Project Laravel\Pasar-Saham V.2\Analisis-Market\resources\views/Pages/News.blade.php ENDPATH**/ ?>