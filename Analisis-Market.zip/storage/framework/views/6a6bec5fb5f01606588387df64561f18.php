<?php echo $__env->make('Headers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container py-4">
    <form action="<?php echo e(route('Index')); ?>" method="GET">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Information</h5>
                <button type="submit" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Terjadi Error Pada Halaman. Gagal memuat halaman coba lagi </p> <br>
                <p> <?php echo e($error); ?></p>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </form>
</div>
<?php echo $__env->make('Footers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\#Project Laravel\Pasar-Saham V.2\Analisis-Market\resources\views/Components/PageError.blade.php ENDPATH**/ ?>