@include('Headers')

<div class="container py-4">
    <div class="card">
        <div class="card-body">
            @include('Profile')
            <br>

            <div class="card">
                <div class="card-header">
                    Holders
                </div>
                
            </div>
        </div>
    </div>
</div>

@include('Footers')
