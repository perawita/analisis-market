<div class="card-header">
    Profile
</div>
<?php $__currentLoopData = $headerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h6 class="fs-5 col-md-8 m-0 p-0"><?php echo e($data['exchange']); ?></h6>
    <p class="fs-6 col-md-4 "><?php echo e($data['symbolName']); ?></p>
    <?php $__currentLoopData = $priceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="fs-6 col-md-4 m-0 p-0"><?php echo e($data['livePrice']); ?> <?php echo e($data['priceChange']); ?>

            <?php echo e($data['priceChangePercent']); ?></p>
        <p class="fs-8 col-md-4 m-0 p-0"><?php echo e($data['marketTimeNotice']); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="card-header">
    </div>

    <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
        <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e($item['link']); ?>" class="nav-link px-2 link-dark"><?php echo e($item['text']); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\#Project Laravel\Pasar-Saham V.2\Analisis-Market\resources\views/Profile.blade.php ENDPATH**/ ?>