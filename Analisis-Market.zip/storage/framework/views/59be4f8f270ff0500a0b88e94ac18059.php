<div class="card-header d-flex justify-content-between align-items-center">
    <span><?php echo e($compareTitle); ?></span>
    <?php if($compareButton): ?>
        <button class="btn btn-primary" id="request-compare">Compare</button>
    <?php endif; ?>
</div>
<div class="card-body">
    <div class="table-responsive">
        <div class="d-flex flex-row flex-nowrap" style="flex-basis: 33.33%;">
            <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-lg-4 mb-4" style="flex: 0 0 auto;">
                    <div class="card p-3">
                        <figure class="p-3 mb-0">
                            <?php if($compareButton): ?>
                                <div class="form-check">
                                    <input class="form-check-input compare-checkbox" type="checkbox"
                                        value="<?php echo e($item['symbol']); ?>" id="compare-<?php echo e($item['symbol']); ?>"
                                        <?php if(strtolower($item['symbol']) === strtolower($symbol)): ?> checked disabled <?php endif; ?>>
                                    <label class="form-check-label" for="compare-<?php echo e($item['symbol']); ?>">
                                        Compare
                                    </label>
                                </div>
                            <?php endif; ?>
                            <blockquote class="blockquote">
                                <p>
                                    <a
                                        href="<?php echo e(route('summary', ['Symbol' => $item['ticker']])); ?>"><?php echo e($item['ticker']); ?></a>
                                </p>
                            </blockquote>
                            <figcaption class="blockquote-footer mb-0 text-muted">
                                <?php echo e(Str::limit($item['companyName'], 30)); ?>

                            </figcaption>
                        </figure>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const checkboxes = document.querySelectorAll('.compare-checkbox');
        const buttonCompare = document.getElementById('request-compare');

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                const checkedCheckboxes = document.querySelectorAll(
                    '.compare-checkbox:checked');
                if (checkedCheckboxes.length > 4) {
                    this.checked = false;
                }
            });
        });

        buttonCompare.addEventListener('click', function() {
            const selectedSymbols = [];
            checkboxes.forEach(function(checkbox) {
                if (checkbox.checked) {
                    selectedSymbols.push(checkbox.value);
                }
            });

            let url = `/quote/compare/<?php echo e($symbol); ?>`;
            if (selectedSymbols.length > 1) {
                const comps = selectedSymbols.filter(symbol => symbol.toLowerCase() !==
                    '<?php echo e($symbol); ?>'.toLowerCase()).join(',');
                url = `/quote/compare/<?php echo e($symbol); ?>?comps=${comps}`;
            }
            window.location.href = url;

        });
    });
</script>
<?php /**PATH C:\#Project Laravel\Pasar-Saham V.2\Analisis-Market\resources\views/Compare.blade.php ENDPATH**/ ?>